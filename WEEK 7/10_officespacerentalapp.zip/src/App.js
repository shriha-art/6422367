import React from 'react';

const offices = [
    { name: 'Office One', rent: 50000, address: 'Address 1' },
    { name: 'Office Two', rent: 70000, address: 'Address 2' }
];

function App() {
  return (
    <div>
      <h1>Office Space Rental</h1>
      <img src="office.jpg" alt="Office" />
      <ul>
        {offices.map((office, index) => (
          <li key={index}>
            {office.name} - 
            <span style={{color: office.rent > 60000 ? 'green' : 'red'}}>
              ₹{office.rent}
            </span> - {office.address}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;