# 17_FetchUserApp

Fetches user data from https://api.randomuser.me/
