# 16_MailRegisterApp

Registration form with input validation.
