# 14_ContextAPIApp

Uses React Context API to pass theme between components.
