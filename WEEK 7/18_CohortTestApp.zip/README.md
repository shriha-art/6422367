# 18_CohortTestApp

React app for testing cohort dashboard using Enzyme.
