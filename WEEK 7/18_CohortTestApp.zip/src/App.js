// Main component file for 18_CohortTestApp
