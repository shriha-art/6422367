import React, { useState } from 'react';

function GuestPage() {
  return <h2>Welcome Guest! Browse Flights</h2>;
}

function UserPage() {
  return <h2>Welcome User! You can book tickets now.</h2>;
}

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div>
      <h1>Ticket Booking App</h1>
      <button onClick={() => setIsLoggedIn(!isLoggedIn)}>
        {isLoggedIn ? "Logout" : "Login"}
      </button>
      {isLoggedIn ? <UserPage /> : <GuestPage />}
    </div>
  );
}

export default App;