import React from 'react';

const players = [
    { name: 'Virat', score: 80 },
    { name: 'Rohit', score: 60 },
    { name: 'Dhoni', score: 75 },
    { name: 'KL Rahul', score: 55 },
    { name: 'Jadeja', score: 85 }
];

const highScorers = players.filter(p => p.score >= 70);

const ListofPlayers = () => (
    <div>
        <h2>High Scorers</h2>
        <ul>{highScorers.map((player, index) => <li key={index}>{player.name} - {player.score}</li>)}</ul>
    </div>
);

export default ListofPlayers;