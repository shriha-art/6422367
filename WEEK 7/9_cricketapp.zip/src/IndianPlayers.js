import React from 'react';

const T20players = ['Player1', 'Player2'];
const RanjiTrophyPlayers = ['Player3', 'Player4'];

const merged = [...T20players, ...RanjiTrophyPlayers];

const IndianPlayers = () => (
    <div>
        <h2>All Players</h2>
        <ul>{merged.map((player, index) => <li key={index}>{player}</li>)}</ul>
    </div>
);

export default IndianPlayers;