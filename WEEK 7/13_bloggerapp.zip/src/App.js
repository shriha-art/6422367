import React, { useState } from 'react';

function BookDetails() {
  return <div>Book Details Component</div>;
}

function BlogDetails() {
  return <div>Blog Details Component</div>;
}

function CourseDetails() {
  return <div>Course Details Component</div>;
}

function App() {
  const [type, setType] = useState("book");

  return (
    <div>
      <h1>Blogger App</h1>
      <button onClick={() => setType("book")}>Book</button>
      <button onClick={() => setType("blog")}>Blog</button>
      <button onClick={() => setType("course")}>Course</button>

      {type === "book" && <BookDetails />}
      {type === "blog" && <BlogDetails />}
      {type === "course" && <CourseDetails />}
    </div>
  );
}

export default App;