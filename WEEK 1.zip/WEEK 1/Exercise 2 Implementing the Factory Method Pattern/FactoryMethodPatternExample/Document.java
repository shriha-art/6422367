package FactoryMethodPatternExample;

public interface Document {
	void open();
}
