import React, { Component } from 'react';

class About extends Component {
  render() {
    return <h1>Welcome to the About page of the Student Management Portal</h1>;
  }
}

export default About;