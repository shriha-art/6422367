import React, { Component } from 'react';

class Contact extends Component {
  render() {
    return <h1>Welcome to the Contact page of the Student Management Portal</h1>;
  }
}

export default Contact;