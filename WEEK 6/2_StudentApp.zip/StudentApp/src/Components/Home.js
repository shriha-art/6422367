import React, { Component } from 'react';

class Home extends Component {
  render() {
    return <h1>Welcome to the Home page of Student Management Portal</h1>;
  }
}

export default Home;