
import React from 'react';
import CohortDetails from './components/CohortDetails';

function App() {
  return (
    <div>
      <CohortDetails name="React Bootcamp" status="ongoing" startDate="2025-07-01" endDate="2025-08-01" />
      <CohortDetails name="Angular Training" status="completed" startDate="2025-05-01" endDate="2025-06-01" />
    </div>
  );
}

export default App;
