import React from 'react';
import CountPeople from './Components/CountPeople';

function App() {
  return (
    <div>
      <CountPeople />
    </div>
  );
}

export default App;