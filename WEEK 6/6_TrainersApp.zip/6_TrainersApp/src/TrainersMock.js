
const trainers = [
    { TrainerId: "T001", Name: "Alice", Email: "alice@example.com", Phone: "1234567890", Technology: "React", Skills: ["JS", "React"] },
    { TrainerId: "T002", Name: "Bob", Email: "bob@example.com", Phone: "2345678901", Technology: "Angular", Skills: ["TS", "Angular"] }
];

export default trainers;
