
import React, { Component } from 'react';

class Cart extends Component {
    render() {
        return (
            <div>
                <h2>{this.props.itemname}</h2>
                <p>Price: ₹{this.props.price}</p>
            </div>
        );
    }
}

export default Cart;
