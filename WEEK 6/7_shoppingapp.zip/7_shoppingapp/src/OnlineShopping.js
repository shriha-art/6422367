
import React, { Component } from 'react';
import Cart from './Cart';

class OnlineShopping extends Component {
    constructor() {
        super();
        this.state = {
            items: [
                { itemname: "Shirt", price: 1200 },
                { itemname: "Jeans", price: 2500 },
                { itemname: "Shoes", price: 3000 },
                { itemname: "Hat", price: 800 },
                { itemname: "Jacket", price: 4000 }
            ]
        };
    }

    render() {
        return (
            <div>
                <h1>Online Shopping</h1>
                {this.state.items.map((item, index) => (
                    <Cart key={index} itemname={item.itemname} price={item.price} />
                ))}
            </div>
        );
    }
}

export default OnlineShopping;
